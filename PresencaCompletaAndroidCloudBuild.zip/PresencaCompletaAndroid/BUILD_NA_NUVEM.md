# Gerar o APK pelo celular, sem computador

Este projeto contém um workflow do GitHub Actions que compila automaticamente o APK universal.

## Resultado

O workflow gera um APK de debug assinado pelo Android, instalável diretamente em celulares Android.

## Como usar

1. Crie um repositório no GitHub pelo navegador do celular.
2. Envie todos os arquivos desta pasta para o repositório.
3. Abra a aba **Actions**.
4. Execute **Build APK Universal**.
5. Quando terminar, abra a execução e baixe o artefato **PresencaCompleta-Universal-APK**.
6. Dentro do arquivo baixado estará o `.apk` pronto para instalar e compartilhar.

O APK de debug é adequado para uso pessoal e testes. Para publicação na Google Play ou distribuição profissional, deve-se gerar uma versão release com uma chave de assinatura própria.
