package com.presencacompleta.app

import android.app.*
import android.graphics.*
import androidx.core.content.FileProvider
import java.io.File
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

private data class Guest(val id: String, val name: String, var present: Boolean)
private data class Event(val id: String, val name: String, val date: String, val token: String)

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: android.content.SharedPreferences
    private var api: SupabaseApi? = null
    private var event: Event? = null
    private val guests = mutableListOf<Guest>()
    private lateinit var list: LinearLayout
    private lateinit var stats: TextView
    private lateinit var title: TextView
    private lateinit var search: EditText
    private var allEvents = mutableListOf<Event>()

    private val pickPdf = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPdf(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("presenca", MODE_PRIVATE)
        PDFBoxResourceLoader.init(applicationContext)
        showStart()
    }

    private fun showStart() {
        val url = prefs.getString("url", "") ?: ""
        val key = prefs.getString("key", "") ?: ""
        if (url.isBlank() || key.isBlank() || prefs.getString("access", "").isNullOrBlank()) showLogin() else {
            api = SupabaseApi(url.trimEnd('/'), key, prefs.getString("access", "")!!, prefs.getString("uid", "") ?: "")
            loadEvents()
        }
    }

    private fun base(titleText: String): LinearLayout {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,24,28,20) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val t = TextView(this).apply { text = titleText; textSize = 23f; setTypeface(null, 1) }
        bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bar)
        return root
    }

    private fun showLogin() {
        val root = base("Presença Completa")
        root.addView(TextView(this).apply { text = "Login do administrador e conexão online"; textSize = 16f; setPadding(0,10,0,18) })
        val url = EditText(this).apply { hint = "URL do Supabase (https://...supabase.co)"; setSingleLine() }
        val key = EditText(this).apply { hint = "Chave anon/publishable"; setSingleLine() }
        val email = EditText(this).apply { hint = "E-mail do administrador"; inputType = 33; setSingleLine() }
        val pass = EditText(this).apply { hint = "Senha"; inputType = 129; setSingleLine() }
        listOf(url,key,email,pass).forEach { root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin=12 }) }
        val b = Button(this).apply { text = "Entrar" }
        root.addView(b)
        b.setOnClickListener {
            if (url.text.isBlank() || key.text.isBlank() || email.text.isBlank() || pass.text.isBlank()) { toast("Preencha todos os campos"); return@setOnClickListener }
            b.isEnabled=false
            lifecycleScope.launch {
                try {
                    val r = SupabaseApi(url.text.toString().trimEnd('/'), key.text.toString().trim(), "", "").login(email.text.toString(), pass.text.toString())
                    prefs.edit().putString("url",url.text.toString().trimEnd('/')).putString("key",key.text.toString().trim()).putString("access",r.first).putString("uid",r.second).apply()
                    api = SupabaseApi(url.text.toString().trimEnd('/'), key.text.toString().trim(), r.first, r.second)
                    loadEvents()
                } catch(e: Exception) { toast("Falha no login: ${e.message}"); b.isEnabled=true }
            }
        }
        val help = TextView(this).apply { text = "Use o mesmo projeto Supabase da versão web segura. Nunca coloque a chave service_role neste aplicativo."; setPadding(0,20,0,0) }
        root.addView(help)
        setContentView(root)
    }

    private fun loadEvents() {
        lifecycleScope.launch {
            try { allEvents = api!!.events().toMutableList(); showEvents() }
            catch(e:Exception){ toast("Erro ao carregar eventos: ${e.message}"); showEvents() }
        }
    }

    private fun showEvents() {
        val root = base("Meus eventos")
        val newB = Button(this).apply { text = "＋ Novo evento" }
        root.addView(newB)
        newB.setOnClickListener { createEventDialog() }
        if (allEvents.isEmpty()) root.addView(TextView(this).apply { text="Nenhum evento criado ainda."; textSize=17f; setPadding(0,25,0,0) })
        allEvents.forEach { ev ->
            val b = Button(this).apply { text = "${ev.name}\n${ev.date}"; gravity=Gravity.START; setPadding(20,16,20,16) }
            root.addView(b, LinearLayout.LayoutParams(-1,-2).apply { topMargin=10 })
            b.setOnClickListener { openEvent(ev) }
        }
        val logout = TextView(this).apply { text="Sair / trocar conta"; setPadding(0,28,0,10); setTextColor(0xff1565c0.toInt()) }
        root.addView(logout); logout.setOnClickListener { prefs.edit().clear().apply(); api=null; showLogin() }
        setContentView(root)
    }

    private fun createEventDialog() {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(35,10,35,5)}
        val n=EditText(this).apply{hint="Nome do evento"}; val d=EditText(this).apply{hint="Data (AAAA-MM-DD)"}
        box.addView(n); box.addView(d)
        AlertDialog.Builder(this).setTitle("Novo evento").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Criar"){_,_->
            lifecycleScope.launch { try { val ev=api!!.createEvent(n.text.toString(), d.text.toString()); allEvents.add(0,ev); openEvent(ev) } catch(e:Exception){toast("Erro: ${e.message}")} }
        }.show()
    }

    private fun openEvent(ev: Event) {
        event=ev; guests.clear()
        lifecycleScope.launch { try { guests.addAll(api!!.guests(ev.id)); showEvent() } catch(e:Exception){toast("Erro: ${e.message}"); showEvent()} }
    }

    private fun showEvent() {
        val ev=event ?: return
        val root=base(ev.name)
        title=root.getChildAt(0) as TextView
        val sub=TextView(this).apply{text="${ev.date} • ${guests.size} convidados";textSize=15f}
        root.addView(sub)
        val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val imp=Button(this).apply{text="Importar PDF"}; val add=Button(this).apply{text="Adicionar"}; val refresh=Button(this).apply{text="Atualizar"}
        actions.addView(imp,LinearLayout.LayoutParams(0,-2,1f)); actions.addView(add,LinearLayout.LayoutParams(0,-2,1f)); actions.addView(refresh,LinearLayout.LayoutParams(0,-2,1f)); root.addView(actions)
        imp.setOnClickListener{pickPdf.launch(arrayOf("application/pdf"))}; add.setOnClickListener{addGuestDialog()}; refresh.setOnClickListener{openEvent(ev)}
        val share=Button(this).apply{text="Gerar e compartilhar PDF"}; root.addView(share); share.setOnClickListener{shareSummary()}
        stats=TextView(this).apply{textSize=17f;setPadding(0,12,0,8)}; root.addView(stats)
        search=EditText(this).apply{hint="Pesquisar convidado";setSingleLine()}; root.addView(search)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; root.addView(list,LinearLayout.LayoutParams(-1,0,1f))
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){renderGuests()};override fun afterTextChanged(e:android.text.Editable?){}})
        setContentView(root); renderGuests()
    }

    private fun renderGuests(){
        if (!::list.isInitialized) return
        list.removeAllViews(); val q=search.text.toString().trim().lowercase(Locale.getDefault()); val filtered=guests.filter{it.name.lowercase(Locale.getDefault()).contains(q)}
        val yes=guests.count{it.present}; stats.text="Presentes: $yes   •   Ausentes: ${guests.size-yes}   •   Total: ${guests.size}"
        filtered.forEach { g ->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            val cb=CheckBox(this).apply{text=g.name;isChecked=g.present;textSize=16f}
            val del=TextView(this).apply{text="✕";textSize=22f;setPadding(14,8,4,8);setTextColor(0xffc62828.toInt())}
            row.addView(cb,LinearLayout.LayoutParams(0,-2,1f)); row.addView(del)
            cb.setOnClickListener { g.present=cb.isChecked; lifecycleScope.launch{try{api!!.setPresent(g.id,g.present);renderGuests()}catch(e:Exception){toast("Erro: ${e.message}")}} }
            del.setOnClickListener { confirmDelete(g) }
            list.addView(row)
        }
    }

    private fun addGuestDialog(){
        val e=EditText(this).apply{hint="Nome completo"}
        AlertDialog.Builder(this).setTitle("Adicionar convidado").setView(e).setNegativeButton("Cancelar",null).setPositiveButton("Adicionar"){_,_->
            val n=e.text.toString().trim(); if(n.isBlank())return@setPositiveButton
            lifecycleScope.launch{try{val g=api!!.addGuest(event!!.id,n);guests.add(g);renderGuests()}catch(x:Exception){toast("Erro: ${x.message}")}}
        }.show()
    }

    private fun confirmDelete(g:Guest){AlertDialog.Builder(this).setTitle("Excluir convidado?").setMessage(g.name).setNegativeButton("Cancelar",null).setPositiveButton("Excluir"){_,_->lifecycleScope.launch{try{api!!.deleteGuest(g.id);guests.remove(g);renderGuests()}catch(e:Exception){toast("Erro: ${e.message}")}}}.show()}

    private fun importPdf(uri:Uri){
        lifecycleScope.launch(Dispatchers.IO){
            try{
                val text=contentResolver.openInputStream(uri)?.use{extractPdf(it)} ?: ""
                val names=extractNames(text)
                withContext(Dispatchers.Main){
                    if(names.isEmpty()){toast("Não encontrei nomes. Se o PDF for escaneado como imagem, esta versão precisa de OCR para esse arquivo.");return@withContext}
                    val preview=names.take(20).joinToString("\n")
                    AlertDialog.Builder(this@MainActivity).setTitle("Importar ${names.size} nomes?").setMessage(preview + if(names.size>20)"\n…" else "").setNegativeButton("Cancelar",null).setPositiveButton("Importar"){_,_->bulkInsert(names)}.show()
                }
            }catch(e:Exception){withContext(Dispatchers.Main){toast("Falha ao ler PDF: ${e.message}")}}
        }
    }

    private fun extractPdf(input:InputStream):String{val doc=PDDocument.load(input);return try{val stripper=com.tom_roush.pdfbox.text.PDFTextStripper();stripper.getText(doc)}finally{doc.close()}}
    private fun extractNames(text:String):List<String>{
        val bad=listOf("lista de convidados","convidados","nome","total","presença","presenca","evento","data","página","pagina","telefone","cpf","documento")
        return text.lines().map{it.replace("\\s+".toRegex()," ").trim()}.filter{it.length>=3&&it.length<=120}.filter{!it.all{c->c.isDigit()||c in ".,/:-"}}.filter{line->bad.none{line.lowercase(Locale.getDefault()).startsWith(it)}}.filter{line->line.count{it.isLetter()}>=3}.distinctBy{normalize(it)}.take(5000)
    }
    private fun normalize(s:String)=java.text.Normalizer.normalize(s.lowercase(Locale.getDefault()),java.text.Normalizer.Form.NFD).replace("\\p{Mn}+".toRegex(),"").replace("[^a-z0-9]".toRegex(),"")

    private fun bulkInsert(names:List<String>){
        lifecycleScope.launch{var ok=0; try{names.forEach{n->if(guests.none{normalize(it.name)==normalize(n)}){guests.add(api!!.addGuest(event!!.id,n));ok++}};renderGuests();toast("$ok nomes importados. Duplicados foram ignorados.")}catch(e:Exception){toast("Importação interrompida: ${e.message}")}}
    }

    private fun shareSummary(){
        val ev=event ?: return
        lifecycleScope.launch(Dispatchers.IO){
            try{
                val file=File(cacheDir,"presenca_${System.currentTimeMillis()}.pdf")
                val doc=android.graphics.pdf.PdfDocument()
                var pageNo=1; var page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,pageNo).create()); var canvas=page.canvas; val paint=Paint().apply{color=Color.BLACK;textSize=13f}
                var y=40f
                fun line(txt:String){ if(y>805){doc.finishPage(page);pageNo++;page=doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,pageNo).create());canvas=page.canvas;y=40f}; canvas.drawText(txt.take(90),30f,y,paint);y+=19f }
                line(ev.name);line("Data: ${ev.date}");line("Presentes: ${guests.count{it.present}} de ${guests.size}");line("")
                guests.forEach{line((if(it.present)"[SIM] " else "[NÃO] ")+it.name)}
                doc.finishPage(page);file.outputStream().use{doc.writeTo(it)};doc.close()
                val uri=FileProvider.getUriForFile(this@MainActivity,"com.presencacompleta.app.fileprovider",file)
                withContext(Dispatchers.Main){startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply{type="application/pdf";putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)},"Compartilhar PDF"))}
            }catch(e:Exception){withContext(Dispatchers.Main){toast("Não foi possível gerar o PDF: ${e.message}")}}
        }
    }

    private fun toast(s:String)=runOnUiThread{Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
}

class SupabaseApi(private val base:String, private val anon:String, private var token:String, private val uid:String){
    private fun req(method:String,path:String,body:String?=null,prefer:String?=null):String{
        val c=URL(base+path).openConnection() as HttpURLConnection
        c.requestMethod=method;c.connectTimeout=20000;c.readTimeout=30000;c.setRequestProperty("apikey",anon);c.setRequestProperty("Authorization","Bearer $token");c.setRequestProperty("Content-Type","application/json")
        if(prefer!=null)c.setRequestProperty("Prefer",prefer)
        if(body!=null){c.doOutput=true;c.outputStream.use{it.write(body.toByteArray())}}
        val code=c.responseCode; val stream=if(code>=400)c.errorStream else c.inputStream; val out=stream?.bufferedReader()?.readText()? : ""
        if(code>=300)throw Exception("HTTP $code ${out.take(300)}");return out
    }
    fun login(email:String,password:String):Pair<String,String>{
        val c=URL(base+"/auth/v1/token?grant_type=password").openConnection() as HttpURLConnection
        c.requestMethod="POST";c.setRequestProperty("apikey",anon);c.setRequestProperty("Content-Type","application/json");c.doOutput=true
        c.outputStream.use{it.write(JSONObject().put("email",email).put("password",password).toString().toByteArray())}
        val code=c.responseCode;val stream=if(code>=400)c.errorStream else c.inputStream;val s=stream.bufferedReader().readText();if(code>=300)throw Exception("HTTP $code ${s.take(300)}");val j=JSONObject(s);return j.getString("access_token") to j.getJSONObject("user").getString("id")
    }
    fun events():List<Event>{val a=JSONArray(req("GET","/rest/v1/events?select=id,name,event_date,public_token&owner_id=eq.$uid&order=created_at.desc"));return List(a.length()){i->val j=a.getJSONObject(i);Event(j.getString("id"),j.getString("name"),j.optString("event_date",""),j.getString("public_token"))}}
    fun createEvent(name:String,date:String):Event{val j=JSONObject().put("name",name).put("event_date",date).put("owner_id",uid);val a=JSONArray(req("POST","/rest/v1/events",j.toString(),"return=representation"));val x=a.getJSONObject(0);return Event(x.getString("id"),x.getString("name"),x.optString("event_date",""),x.getString("public_token"))}
    fun guests(eventId:String):List<Guest>{val a=JSONArray(req("GET","/rest/v1/guests?select=id,name,present&event_id=eq.$eventId&order=name.asc"));return List(a.length()){i->val j=a.getJSONObject(i);Guest(j.getString("id"),j.getString("name"),j.optBoolean("present",false))}}
    fun addGuest(eventId:String,name:String):Guest{val j=JSONObject().put("event_id",eventId).put("name",name).put("present",false);val a=JSONArray(req("POST","/rest/v1/guests",j.toString(),"return=representation"));val x=a.getJSONObject(0);return Guest(x.getString("id"),x.getString("name"),x.optBoolean("present",false))}
    fun setPresent(id:String,present:Boolean){req("PATCH","/rest/v1/guests?id=eq.$id",JSONObject().put("present",present).toString())}
    fun deleteGuest(id:String){req("DELETE","/rest/v1/guests?id=eq.$id")}
}
