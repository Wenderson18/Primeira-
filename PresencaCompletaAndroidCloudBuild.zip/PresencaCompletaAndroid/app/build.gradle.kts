plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.presencacompleta.app"; compileSdk = 35
    defaultConfig { applicationId = "com.presencacompleta.app"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "1.0" }

    // Gera também um único APK universal, contendo as ABIs suportadas.
    // Isso permite compartilhar um único arquivo .apk entre aparelhos Android.
    splits {
        abi {
            isEnable = true
            reset()
            include("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
            isUniversalApk = true
        }
    }

    buildTypes { release { isMinifyEnabled = false; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
