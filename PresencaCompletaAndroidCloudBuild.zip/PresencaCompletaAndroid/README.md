# Presença Completa — Android

Aplicativo Android para controle de presença em eventos, com sincronização online via Supabase.

## Recursos
- Login de administrador.
- Vários eventos por conta.
- Cadastro manual de convidados.
- Importação em massa de nomes de PDF com texto selecionável.
- Detecção de duplicados por normalização do nome.
- Presença SIM/NÃO com atualização online.
- Busca instantânea.
- Totais de presentes, ausentes e total.
- Geração e compartilhamento de PDF pelo menu nativo do Android.
- Dois ou mais celulares podem usar a mesma conta/evento e consultar os mesmos dados.
- Sem permissão ampla de armazenamento: o PDF é escolhido pelo seletor oficial do Android (Storage Access Framework).

## Configuração do Supabase
1. Crie um projeto no Supabase.
2. Execute `supabase_seguro.sql` no SQL Editor.
3. Em Authentication, crie o usuário administrador (e-mail e senha).
4. No aplicativo informe a URL do projeto e a chave anon/publishable.
5. Entre com o e-mail e senha.

**Nunca coloque `service_role`/secret key no aplicativo.**

## Importação de PDF
O importador funciona diretamente para PDFs que possuem texto real (por exemplo, uma lista exportada do Word/Excel). Ele trata cada linha como um possível nome, remove cabeçalhos comuns e elimina duplicados.

PDF escaneado como imagem precisa de OCR. Esta primeira versão identifica isso e pede um PDF com texto. O OCR pode ser acrescentado como módulo posterior sem alterar o banco.

## Compilação
Abra a pasta no Android Studio e aguarde o Gradle baixar as dependências. Depois use **Build > Generate App Bundle / APK > Generate APK**.

O projeto foi preparado para `compileSdk 35`, `minSdk 26` e AndroidX. A versão final pode ser assinada para distribuição direta como APK.

## APK universal

O projeto está configurado para gerar um APK universal, incluindo `armeabi-v7a`, `arm64-v8a`, `x86` e `x86_64`. Assim, para compartilhamento direto entre celulares, use o arquivo universal gerado pelo Gradle.

### Pelo Android Studio
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Execute **Build > Generate App Bundles or APKs > Generate APKs**.
4. Na pasta `app/build/outputs/apk/release/`, escolha o arquivo que contém `universal` no nome.

### Pela linha de comando
No diretório do projeto, execute `./gradlew assembleRelease`. O APK universal será produzido na pasta de saída da variante `release`.

O APK universal tende a ser maior que um APK específico para uma ABI, porque reúne os binários de todas as arquiteturas configuradas. A documentação oficial do Android descreve esse modo como apropriado quando se deseja um único APK compatível com todas as configurações suportadas.
