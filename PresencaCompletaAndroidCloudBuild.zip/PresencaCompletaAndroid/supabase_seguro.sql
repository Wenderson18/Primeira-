-- Banco para o app Presença Completa.
-- Execute no SQL Editor do Supabase.
create extension if not exists pgcrypto;
create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  event_date date,
  public_token uuid not null default gen_random_uuid() unique,
  owner_id uuid not null default auth.uid(),
  created_at timestamptz not null default now()
);
create table if not exists public.guests (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  name text not null,
  present boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.events enable row level security;
alter table public.guests enable row level security;
drop policy if exists events_owner_select on public.events;
drop policy if exists events_owner_insert on public.events;
drop policy if exists events_owner_update on public.events;
drop policy if exists events_owner_delete on public.events;
create policy events_owner_select on public.events for select using (owner_id=auth.uid());
create policy events_owner_insert on public.events for insert with check (owner_id=auth.uid());
create policy events_owner_update on public.events for update using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create policy events_owner_delete on public.events for delete using (owner_id=auth.uid());
drop policy if exists guests_owner_select on public.guests;
drop policy if exists guests_owner_insert on public.guests;
drop policy if exists guests_owner_update on public.guests;
drop policy if exists guests_owner_delete on public.guests;
create policy guests_owner_select on public.guests for select using (exists(select 1 from public.events e where e.id=guests.event_id and e.owner_id=auth.uid()));
create policy guests_owner_insert on public.guests for insert with check (exists(select 1 from public.events e where e.id=guests.event_id and e.owner_id=auth.uid()));
create policy guests_owner_update on public.guests for update using (exists(select 1 from public.events e where e.id=guests.event_id and e.owner_id=auth.uid())) with check (exists(select 1 from public.events e where e.id=guests.event_id and e.owner_id=auth.uid()));
create policy guests_owner_delete on public.guests for delete using (exists(select 1 from public.events e where e.id=guests.event_id and e.owner_id=auth.uid()));
create or replace function public.get_public_event(p_token uuid)
returns table(event_name text,event_date date,guest_name text,present boolean)
language sql security definer set search_path=public as $$
  select e.name,e.event_date,g.name,g.present from public.events e join public.guests g on g.event_id=e.id where e.public_token=p_token order by g.name;
$$;
revoke all on function public.get_public_event(uuid) from public;
grant execute on function public.get_public_event(uuid) to anon,authenticated;
